package br.com.boys2mans.LoginManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
