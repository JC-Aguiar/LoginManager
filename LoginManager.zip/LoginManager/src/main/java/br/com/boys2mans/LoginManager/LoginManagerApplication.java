package br.com.boys2mans.LoginManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginManagerApplication.class, args);
	}

}
